// Company: 
Southeast University in China
// Engineer: 
Wang Tianpeng
// Create Date: 2020/02/02 18:34:55
// Project Name: dehaze
// Tool Versions: Vivado 2017.4
// Revision: v1.0

Create a new vivado project in your computer using tcl file:

Step1: Open Vivado 2017.4 Tcl Shell
Step2: Set file directory : Type - cd X1:/Desktop/dehaze_new
Step3: Run dehaze.tcl: Type - vivado -mode tcl -source dehaze.tcl
Step4: Then a new dehaze project will be created in current directory.


